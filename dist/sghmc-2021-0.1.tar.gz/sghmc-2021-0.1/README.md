# SGHMC Algorithm Implementation
Qinzhe Wang (qw92@duke.edu)
Yi Mi (yi.mi@duke.edu)
